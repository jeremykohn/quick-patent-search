Quick Patent Search
===================

Chrome extension to quickly search U.S. patents by number.

Instructions:
- Click the icon.
- Type in the number of any utility or design patent, and press return.
- That's it. Happy searching!
